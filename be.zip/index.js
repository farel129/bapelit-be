// server.js
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { createClient } = require('@supabase/supabase-js');
const PDFDocument = require('pdfkit');
require('dotenv').config();
const puppeteer = require('puppeteer');
const Handlebars = require('handlebars');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 5000;

// Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// Middleware
app.use(cors());
app.use(express.json());

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'bapelit123';

// Auth middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Admin middleware - hanya admin yang bisa akses
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Login endpoint (tetap sama, tapi tambah role dalam response)
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Get user from database
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();

    console.log('Login request:', req.body) // debug isi
    console.log('User from Supabase:', user) // debug hasil query
    console.log('User password dari Supabase:', user.password)

    if (error || !user) {
      return res.status(400).json({ error: 'Email atau password salah' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Email atau password salah' });
    }

    // Generate JWT token (include role)
    // Di endpoint login, tambahkan bidang
    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        jabatan: user.jabatan,
        bidang: user.bidang, // ✅ Tambahan
        role: user.role || 'user'
      },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        jabatan: user.jabatan,
        role: user.role || 'user'
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });

  }

});

// Endpoint untuk admin membuat akun baru
app.post('/api/admin/users', authenticateToken, async (req, res) => {
  const { name, email, password, jabatan = '', role = 'user', bidang = '' } = req.body;

  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Hanya admin yang boleh membuat user' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const { data, error } = await supabase
      .from('users')
      .insert([{ name, email, password: hashedPassword, jabatan, role, bidang }])
      .select();


    if (error) {
      console.error('Supabase error:', error);
      return res.status(500).json({ error: error.message });
    }

    res.status(201).json({ message: 'User berhasil dibuat', user: data[0] });
  } catch (err) {
    console.error('Server error:', err);
    res.status(500).json({ error: 'Gagal membuat user' });
  }
});

// 🆕 Endpoint untuk admin melihat semua user
app.get('/api/admin/users', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, email, name, jabatan, role, bidang, created_at')
      .order('created_at', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({
      message: 'Daftar semua user',
      data: data || [],
      total: data?.length || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});



// 🆕 Endpoint untuk admin menghapus user
app.delete('/api/admin/users/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;

    // Jangan biarkan admin hapus dirinya sendiri
    if (userId == req.user.id) {
      return res.status(400).json({ error: 'Tidak bisa menghapus akun sendiri' });
    }

    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', userId);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'User berhasil dihapus' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 🆕 Endpoint untuk admin reset password user
app.put('/api/admin/users/:id/reset-password', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { newPassword } = req.body;
    const userId = req.params.id;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'Password minimal 6 karakter' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    const { error } = await supabase
      .from('users')
      .update({ password: hashedPassword })
      .eq('id', userId);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'Password user berhasil direset' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get User (untuk dropdown, bisa diakses semua user yang login)
app.get('/api/users/basic', authenticateToken, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, name, jabatan')
      .order('name', { ascending: true });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({
      message: 'Berhasil mengambil data user (name & jabatan)',
      data: data || [],
      total: data?.length || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create incoming mail
const multer = require('multer');

// Setup multer untuk upload multiple files
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = 'uploads/surat-masuk/';
    // Buat folder jika belum ada
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Generate nama file unik dengan timestamp
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'surat-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// Filter file - hanya izinkan gambar
const fileFilter = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png|gif|webp/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb(new Error('Hanya file gambar (JPEG, JPG, PNG, GIF, WEBP) yang diizinkan!'));
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // Maksimal 5MB per file
    files: 10 // Maksimal 10 files
  },
  fileFilter: fileFilter
});

// POST endpoint dengan upload multiple photos
app.post('/api/surat-masuk', authenticateToken, upload.array('photos', 10), async (req, res) => {
  try {
    const {
      asal_instansi,
      nomor_surat,
      tujuan_jabatan,
      keterangan,
      perihal,
      disposisi_kepada,
      tindakan,
      sifat,
      catatan
    } = req.body;

    // Validasi input
    if (!asal_instansi || !nomor_surat || !tujuan_jabatan) {
      // Hapus file yang sudah diupload jika validasi gagal
      if (req.files && req.files.length > 0) {
        req.files.forEach(file => {
          fs.unlinkSync(file.path);
        });
      }
      return res.status(400).json({
        error: 'Asal instansi, nomor surat, dan tujuan jabatan wajib diisi'
      });
    }

    // Siapkan data untuk insert surat
    const suratData = {
      asal_instansi,
      nomor_surat,
      tujuan_jabatan,
      keterangan,
      perihal: perihal || null,
      disposisi_kepada: disposisi_kepada || null,
      tindakan: tindakan || null,
      sifat: sifat || null,
      catatan: catatan || null,
      created_by: req.user.id,
      status: 'pending',
      created_at: new Date().toISOString(),
      processed_at: new Date().toISOString(),

    };

    // Insert surat masuk terlebih dahulu
    const { data: suratResult, error: suratError } = await supabase
      .from('surat_masuk')
      .insert([suratData])
      .select()
      .single();

    if (suratError) {
      // Hapus file yang sudah diupload jika database insert gagal
      if (req.files && req.files.length > 0) {
        req.files.forEach(file => {
          fs.unlinkSync(file.path);
        });
      }
      return res.status(400).json({ error: suratError.message });
    }

    // Simpan data foto-foto jika ada
    let photoCount = 0;
    if (req.files && req.files.length > 0) {
      const photoData = req.files.map(file => ({
        surat_id: suratResult.id,
        foto_path: file.path,
        foto_filename: file.filename,
        foto_original_name: file.originalname,
        file_size: file.size,
        created_at: new Date().toISOString()
      }));

      const { error: photoError } = await supabase
        .from('surat_photos')
        .insert(photoData);

      if (photoError) {
        // Jika gagal simpan foto, hapus surat dan semua file
        await supabase.from('surat_masuk').delete().eq('id', suratResult.id);
        req.files.forEach(file => {
          fs.unlinkSync(file.path);
        });
        return res.status(400).json({ error: 'Gagal menyimpan foto: ' + photoError.message });
      }

      photoCount = req.files.length;
    }

    // Create notification for target jabatan
    const { data: targetUsers } = await supabase
      .from('users')
      .select('id')
      .eq('jabatan', tujuan_jabatan);

    if (targetUsers && targetUsers.length > 0) {
      const notifications = targetUsers.map(user => ({
        user_id: user.id,
        surat_id: suratResult.id,
        message: `Surat masuk baru dari ${asal_instansi} untuk jabatan ${tujuan_jabatan}`,
        is_read: false,
        created_at: new Date().toISOString()
      }));

      await supabase
        .from('notifications')
        .insert(notifications);
    }

    res.status(201).json({
      message: 'Surat masuk berhasil dibuat',
      data: {
        ...suratResult,
        photo_count: photoCount,
        has_photos: photoCount > 0
      }
    });
  } catch (error) {
    // Hapus file yang sudah diupload jika terjadi error
    if (req.files && req.files.length > 0) {
      req.files.forEach(file => {
        fs.unlinkSync(file.path);
      });
    }
    res.status(500).json({ error: error.message });
  }
});

// Endpoint untuk mengirim surat ke jabatan lain
// Endpoint untuk mengirim surat ke jabatan lain
app.post('/api/surat/:id/send-to-jabatan', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { tujuan_jabatan, disposisi_kepada } = req.body;

    // Validasi input
    if (!tujuan_jabatan || !disposisi_kepada) {
      return res.status(400).json({
        error: 'Tujuan jabatan dan disposisi kepada wajib diisi'
      });
    }

    // Validasi apakah surat exists
    const { data: existingSurat, error: fetchError } = await supabase
      .from('surat_masuk')
      .select('*')
      .eq('id', id)
      .single();

    if (fetchError || !existingSurat) {
      return res.status(404).json({
        error: 'Surat tidak ditemukan'
      });
    }

    // Cek apakah surat sudah diproses sebelumnya
    if (existingSurat.status === 'sent' || existingSurat.status === 'forwarded') {
      return res.status(400).json({
        error: 'Surat sudah dikirim atau diteruskan sebelumnya'
      });
    }

    // Update data surat dengan tujuan jabatan dan disposisi baru
    const updateData = {
      tujuan_jabatan,
      disposisi_kepada,
      processed_at: new Date().toISOString(),
    };

    const { data: updatedSurat, error: updateError } = await supabase
      .from('surat_masuk')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (updateError) {
      return res.status(400).json({ 
        error: 'Gagal mengupdate surat: ' + updateError.message 
      });
    }

    // Hapus notifikasi lama untuk jabatan sebelumnya jika ada
    if (existingSurat.tujuan_jabatan !== tujuan_jabatan) {
      const { data: oldTargetUsers } = await supabase
        .from('users')
        .select('id')
        .eq('jabatan', existingSurat.tujuan_jabatan);

      if (oldTargetUsers && oldTargetUsers.length > 0) {
        const oldUserIds = oldTargetUsers.map(user => user.id);
        await supabase
          .from('notifications')
          .delete()
          .eq('surat_id', id)
          .in('user_id', oldUserIds);
      }
    }

    // Buat notifikasi untuk jabatan tujuan baru
    console.log('Mencari users dengan jabatan:', tujuan_jabatan);
    const { data: targetUsers, error: userFetchError } = await supabase
      .from('users')
      .select('id, name, jabatan')
      .eq('jabatan', tujuan_jabatan);

    console.log('Target users found:', targetUsers);
    console.log('User fetch error:', userFetchError);

    if (userFetchError) {
      console.error('Error fetching target users:', userFetchError);
    }

    let notificationCount = 0;
    if (targetUsers && targetUsers.length > 0) {
      const notifications = targetUsers.map(user => ({
        user_id: user.id,
        surat_id: id, // jangan parseInt, biarkan sebagai string
        message: `Surat dari ${existingSurat.asal_instansi} telah dikirim ke jabatan ${tujuan_jabatan} (No. ${existingSurat.nomor_surat})`,
        is_read: false,
        created_at: new Date().toISOString()
      }));

      console.log('Notifications to insert:', notifications);

      const { data: insertedNotifications, error: notifError } = await supabase
        .from('notifications')
        .insert(notifications)
        .select();

      if (notifError) {
        console.error('Error creating notifications:', notifError);
        console.error('Notification error details:', JSON.stringify(notifError, null, 2));
      } else {
        console.log('Notifications created successfully:', insertedNotifications);
        notificationCount = insertedNotifications ? insertedNotifications.length : 0;
      }
    } else {
      console.log('No target users found for jabatan:', tujuan_jabatan);
    }

    // Buat notifikasi juga untuk jabatan disposisi_kepada jika berbeda
    let disposisiNotificationCount = 0;
    if (disposisi_kepada && disposisi_kepada !== tujuan_jabatan) {
      console.log('Mencari users untuk disposisi kepada:', disposisi_kepada);
      const { data: disposisiUsers, error: disposisiUserError } = await supabase
        .from('users')
        .select('id, name, jabatan')
        .eq('jabatan', disposisi_kepada);

      console.log('Disposisi users found:', disposisiUsers);
      console.log('Disposisi user fetch error:', disposisiUserError);

      if (disposisiUserError) {
        console.error('Error fetching disposisi users:', disposisiUserError);
      }

      if (disposisiUsers && disposisiUsers.length > 0) {
        const disposisiNotifications = disposisiUsers.map(user => ({
          user_id: user.id,
          surat_id: id, // jangan parseInt, biarkan sebagai string
          message: `Anda mendapat disposisi surat dari ${existingSurat.asal_instansi} (No. ${existingSurat.nomor_surat})`,
          is_read: false,
          created_at: new Date().toISOString()
        }));

        console.log('Disposisi notifications to insert:', disposisiNotifications);

        const { data: insertedDisposisiNotifications, error: disposisiNotifError } = await supabase
          .from('notifications')
          .insert(disposisiNotifications)
          .select();

        if (disposisiNotifError) {
          console.error('Error creating disposisi notifications:', disposisiNotifError);
          console.error('Disposisi notification error details:', JSON.stringify(disposisiNotifError, null, 2));
        } else {
          console.log('Disposisi notifications created successfully:', insertedDisposisiNotifications);
          disposisiNotificationCount = insertedDisposisiNotifications ? insertedDisposisiNotifications.length : 0;
        }
      } else {
        console.log('No disposisi users found for jabatan:', disposisi_kepada);
      }
    }

    // Log activity untuk audit trail
    const activityData = {
      surat_id: id, // jangan parseInt, biarkan sebagai string
      user_id: req.user.id,
      action: 'send_to_jabatan',
      details: `Surat dikirim ke jabatan ${tujuan_jabatan} dengan disposisi kepada ${disposisi_kepada}`,
      old_values: JSON.stringify({
        tujuan_jabatan: existingSurat.tujuan_jabatan,
        disposisi_kepada: existingSurat.disposisi_kepada,
        status: existingSurat.status
      }),
      new_values: JSON.stringify({
        tujuan_jabatan,
        disposisi_kepada,
      }),
      created_at: new Date().toISOString()
    };

    await supabase
      .from('surat_activities')
      .insert([activityData]);

    res.status(200).json({
      message: `Surat berhasil dikirim ke jabatan ${tujuan_jabatan}`,
      data: {
        ...updatedSurat,
        target_users_count: targetUsers ? targetUsers.length : 0,
        notification_count: notificationCount,
        disposisi_notification_count: disposisiNotificationCount,
        sent_to_jabatan: tujuan_jabatan,
        disposisi_kepada: disposisi_kepada
      }
    });

  } catch (error) {
    console.error('Error in send-to-jabatan:', error);
    res.status(500).json({ 
      error: 'Terjadi kesalahan server: ' + error.message 
    });
  }
});

// GET endpoint untuk mengambil semua surat masuk dengan info foto
app.get('/api/surat-masuk/all', authenticateToken, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('surat_masuk')
      .select(`
        *,
        users!surat_masuk_created_by_fkey (name, jabatan),
        processed_user:users!surat_masuk_processed_by_fkey (name, jabatan),
        surat_photos (id, foto_filename, foto_original_name, file_size)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    // Tambahkan info foto untuk setiap surat
    const dataWithPhotoInfo = data?.map(surat => ({
      ...surat,
      photo_count: surat.surat_photos ? surat.surat_photos.length : 0,
      has_photos: surat.surat_photos && surat.surat_photos.length > 0,
      photos: surat.surat_photos?.map(photo => ({
        id: photo.id,
        filename: photo.foto_original_name,
        size: photo.file_size,
        url: `/api/surat-masuk/photo/${photo.id}`
      })) || []
    })) || [];

    res.json({
      message: 'Berhasil mengambil semua surat masuk',
      data: dataWithPhotoInfo,
      total: dataWithPhotoInfo.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET endpoint untuk mengambil foto tertentu berdasarkan photo ID
app.get('/api/surat-masuk/photo/:photoId', authenticateToken, async (req, res) => {
  try {
    const { photoId } = req.params;

    // Ambil data foto
    const { data: photo, error } = await supabase
      .from('surat_photos')
      .select('foto_path, foto_filename, foto_original_name')
      .eq('id', photoId)
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    if (!photo || !photo.foto_path) {
      return res.status(404).json({ error: 'Foto tidak ditemukan' });
    }

    // Cek apakah file masih ada
    if (!fs.existsSync(photo.foto_path)) {
      return res.status(404).json({ error: 'File foto tidak ditemukan' });
    }

    // Set header content type berdasarkan ekstensi file
    const ext = path.extname(photo.foto_filename).toLowerCase();
    let contentType = 'image/jpeg'; // default

    switch (ext) {
      case '.png':
        contentType = 'image/png';
        break;
      case '.gif':
        contentType = 'image/gif';
        break;
      case '.webp':
        contentType = 'image/webp';
        break;
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `inline; filename="${photo.foto_original_name}"`);

    // Stream file ke response
    const fileStream = fs.createReadStream(photo.foto_path);
    fileStream.pipe(res);

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET endpoint untuk mengambil semua foto dari surat tertentu
app.get('/api/surat-masuk/:suratId/photos', authenticateToken, async (req, res) => {
  try {
    const { suratId } = req.params;

    const { data: photos, error } = await supabase
      .from('surat_photos')
      .select('*')
      .eq('surat_id', suratId)
      .order('created_at', { ascending: true });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    const photosWithUrls = photos.map(photo => ({
      id: photo.id,
      filename: photo.foto_original_name,
      size: photo.file_size,
      url: `/api/surat-masuk/photo/${photo.id}`,
      created_at: photo.created_at
    }));

    res.json({
      message: 'Berhasil mengambil foto surat',
      data: photosWithUrls,
      total: photosWithUrls.length
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE endpoint untuk menghapus foto tertentu
app.delete('/api/surat-masuk/photo/:photoId', authenticateToken, async (req, res) => {
  try {
    const { photoId } = req.params;

    // Ambil data foto dan surat terkait
    const { data: photo, error: fetchError } = await supabase
      .from('surat_photos')
      .select(`
        *,
        surat_masuk (created_by)
      `)
      .eq('id', photoId)
      .single();

    if (fetchError) {
      return res.status(400).json({ error: fetchError.message });
    }

    if (!photo) {
      return res.status(404).json({ error: 'Foto tidak ditemukan' });
    }

    // Cek authorization
    if (photo.surat_masuk.created_by !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Tidak memiliki izin untuk menghapus foto ini' });
    }

    // Hapus dari database
    const { error: deleteError } = await supabase
      .from('surat_photos')
      .delete()
      .eq('id', photoId);

    if (deleteError) {
      return res.status(400).json({ error: deleteError.message });
    }

    // Hapus file fisik
    if (photo.foto_path && fs.existsSync(photo.foto_path)) {
      fs.unlinkSync(photo.foto_path);
    }

    res.json({
      message: 'Foto berhasil dihapus'
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE endpoint untuk menghapus surat masuk beserta semua fotonya
app.delete('/api/surat-masuk/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Ambil data surat dan foto-fotonya
    const { data: surat, error: fetchError } = await supabase
      .from('surat_masuk')
      .select(`
        created_by,
        surat_photos (foto_path)
      `)
      .eq('id', id)
      .single();

    if (fetchError) {
      return res.status(400).json({ error: fetchError.message });
    }

    if (!surat) {
      return res.status(404).json({ error: 'Surat tidak ditemukan' });
    }

    // Cek authorization
    if (surat.created_by !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Tidak memiliki izin untuk menghapus surat ini' });
    }

    // Hapus semua foto dari database (cascade akan menghapus di surat_photos)
    const { error: deleteError } = await supabase
      .from('surat_masuk')
      .delete()
      .eq('id', id);

    if (deleteError) {
      return res.status(400).json({ error: deleteError.message });
    }

    // Hapus semua file foto
    if (surat.surat_photos && surat.surat_photos.length > 0) {
      surat.surat_photos.forEach(photo => {
        if (photo.foto_path && fs.existsSync(photo.foto_path)) {
          fs.unlinkSync(photo.foto_path);
        }
      });
    }

    res.json({
      message: 'Surat masuk dan semua foto berhasil dihapus'
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get statistics surat masuk
app.get('/api/surat-masuk/stats', authenticateToken, async (req, res) => {
  try {
    // Total surat masuk
    const { count: totalSurat } = await supabase
      .from('surat_masuk')
      .select('*', { count: 'exact', head: true });

    // Surat pending
    const { count: pendingSurat } = await supabase
      .from('surat_masuk')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    // Surat processed
    const { count: processedSurat } = await supabase
      .from('surat_masuk')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'processed');

    // Surat per jabatan
    const { data: suratPerJabatan } = await supabase
      .from('surat_masuk')
      .select('tujuan_jabatan')
      .order('tujuan_jabatan');

    // Hitung surat per jabatan
    const jabatanCount = {};
    suratPerJabatan?.forEach(surat => {
      jabatanCount[surat.tujuan_jabatan] = (jabatanCount[surat.tujuan_jabatan] || 0) + 1;
    });

    res.json({
      message: 'Statistik surat masuk',
      stats: {
        total: totalSurat || 0,
        pending: pendingSurat || 0,
        processed: processedSurat || 0,
        byJabatan: jabatanCount
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get user's notifications
app.get('/api/notifications', authenticateToken, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .select(`
        *,
        surat_masuk (
          id,
          asal_instansi,
          tujuan_jabatan,
          keterangan,
          status,
          created_at
        )
      `)
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Mark notification as read
app.put('/api/notifications/:id/read', authenticateToken, async (req, res) => {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', req.params.id)
      .eq('user_id', req.user.id);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'Notification marked as read' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


app.delete('/api/surat/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // 1. Hapus notifikasi terlebih dahulu
    await supabase
      .from('notifications')
      .delete()
      .eq('surat_id', id);

    // 2. Baru hapus surat
    const { error } = await supabase
      .from('surat_masuk')
      .delete()
      .eq('id', id);

    if (error) throw error;

    res.status(200).json({ message: 'Surat berhasil dihapus' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Gagal menghapus surat', detail: error.message });
  }
});



// Process surat with disposisi
app.post('/api/surat/:id/process', authenticateToken, async (req, res) => {
  try {
    const {
      perihal,
      disposisi_kepada,
      tindakan,
      sifat,
      catatan
    } = req.body;

    const { data, error } = await supabase
      .from('surat_masuk')
      .update({
        perihal,
        disposisi_kepada,
        tindakan,
        sifat,
        catatan,
        processed_by: req.user.id,
        status: 'processed'
      })
      .eq('id', req.params.id)
      .eq('tujuan_jabatan', req.user.jabatan)
      .select()
      .maybeSingle();

    if (error) return res.status(400).json({ error: error.message });

    res.json({
      message: 'Surat berhasil diproses dengan disposisi',
      data
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint untuk meneruskan surat ke bawahan spesifik (berdasarkan nama)
app.post('/api/surat/:id/forward', authenticateToken, async (req, res) => {
  try {
    const { bawahan_users, catatan } = req.body;

    // Validasi input - bawahan_users harus berupa array dengan format [{nama, jabatan}]
    if (!bawahan_users || !Array.isArray(bawahan_users) || bawahan_users.length === 0) {
      return res.status(400).json({ 
        error: 'Data bawahan wajib diisi dalam format array: [{"nama": "...", "jabatan": "..."}]' 
      });
    }

    // Validasi format setiap item dalam array
    for (const bawahan of bawahan_users) {
      if (!bawahan.nama || !bawahan.jabatan) {
        return res.status(400).json({
          error: 'Setiap bawahan harus memiliki nama dan jabatan'
        });
      }
    }

    // Pastikan surat ada
    const { data: surat, error: suratError } = await supabase
      .from('surat_masuk')
      .select('*')
      .eq('id', req.params.id)
      .single();

    if (suratError || !surat) {
      return res.status(404).json({ error: 'Surat tidak ditemukan' });
    }

    // Ambil bidang user yang melakukan forward
    const { data: currentUser, error: userError } = await supabase
      .from('users')
      .select('bidang')
      .eq('id', req.user.id)
      .single();

    if (userError || !currentUser || !currentUser.bidang) {
      return res.status(400).json({ error: 'Data bidang user tidak ditemukan' });
    }

    // Validasi dan ambil data setiap bawahan
    const validatedBawahan = [];
    const notFoundUsers = [];
    const differentBidangUsers = [];

    for (const bawahan of bawahan_users) {
      // Cari user berdasarkan nama dan jabatan
      const { data: targetUser, error: targetError } = await supabase
        .from('users')
        .select('id, name, jabatan, bidang')
        .eq('name', bawahan.nama)
        .eq('jabatan', bawahan.jabatan)
        .single();

      if (targetError || !targetUser) {
        notFoundUsers.push(`${bawahan.nama} (${bawahan.jabatan})`);
        continue;
      }

      // Cek apakah user dalam bidang yang sama
      if (targetUser.bidang !== currentUser.bidang) {
        differentBidangUsers.push(`${bawahan.nama} (${bawahan.jabatan}) - bidang ${targetUser.bidang}`);
        continue;
      }

      // Cek duplikasi (jika ada user yang sama dikirim 2x)
      const isDuplicate = validatedBawahan.find(v => v.id === targetUser.id);
      if (!isDuplicate) {
        validatedBawahan.push(targetUser);
      }
    }

    // Jika ada user yang tidak ditemukan
    if (notFoundUsers.length > 0) {
      return res.status(400).json({
        error: `User tidak ditemukan: ${notFoundUsers.join(', ')}`
      });
    }

    // Jika ada user dengan bidang berbeda
    if (differentBidangUsers.length > 0) {
      return res.status(403).json({
        error: `Tidak dapat meneruskan ke user di bidang berbeda: ${differentBidangUsers.join(', ')}. Hanya bisa meneruskan ke bawahan dalam bidang ${currentUser.bidang}`
      });
    }

    // Jika tidak ada user valid
    if (validatedBawahan.length === 0) {
      return res.status(400).json({
        error: 'Tidak ada user valid untuk diteruskan'
      });
    }

    // Buat notifikasi untuk setiap user yang valid
    const notifications = validatedBawahan.map(user => ({
      user_id: user.id,
      surat_id: req.params.id,
      message: `Surat dan disposisi diteruskan oleh ${req.user.jabatan} kepada ${user.name} (${user.jabatan})` + (catatan ? `: ${catatan}` : ''),
      is_read: false,
      created_at: new Date().toISOString()
    }));

    // Insert notifikasi
    const { data: insertedNotifications, error: notifError } = await supabase
      .from('notifications')
      .insert(notifications)
      .select();

    if (notifError) {
      console.error('Error creating notifications:', notifError);
      return res.status(500).json({
        error: 'Gagal membuat notifikasi: ' + notifError.message
      });
    }

    // Log activity untuk audit trail
    const activityData = {
      surat_id: req.params.id,
      user_id: req.user.id,
      action: 'forward_to_specific_users',
      details: `Surat diteruskan kepada: ${validatedBawahan.map(u => `${u.name} (${u.jabatan})`).join(', ')}`,
      old_values: null,
      new_values: JSON.stringify({
        forwarded_to: validatedBawahan.map(u => ({
          id: u.id,
          name: u.name,
          jabatan: u.jabatan,
          bidang: u.bidang
        })),
        catatan
      }),
      created_at: new Date().toISOString()
    };

    await supabase
      .from('surat_activities')
      .insert([activityData]);

    res.json({
      message: `Surat berhasil diteruskan kepada ${validatedBawahan.length} user dalam bidang ${currentUser.bidang}`,
      forwarded_to: validatedBawahan.map(u => ({
        id: u.id,
        name: u.name,
        jabatan: u.jabatan
      })),
      bidang: currentUser.bidang,
      notification_count: insertedNotifications ? insertedNotifications.length : 0,
      catatan
    });

  } catch (error) {
    console.error('Error in forward to specific users:', error);
    res.status(500).json({ 
      error: 'Terjadi kesalahan server: ' + error.message 
    });
  }
});

// Endpoint helper untuk mendapatkan daftar user dalam bidang yang sama (untuk dropdown)
app.get('/api/users/bawahan-bidang-detail', authenticateToken, async (req, res) => {
  try {
    // Ambil bidang user current
    const { data: currentUser, error: userError } = await supabase
      .from('users')
      .select('bidang')
      .eq('id', req.user.id)
      .single();

    if (userError || !currentUser) {
      return res.status(400).json({ error: 'Data user tidak ditemukan' });
    }

    // Ambil semua user dalam bidang yang sama (kecuali diri sendiri)
    const { data: bawahanUsers, error } = await supabase
      .from('users')
      .select('id, name, jabatan, bidang, email')
      .eq('bidang', currentUser.bidang)
      .neq('id', req.user.id)
      .order('jabatan', { ascending: true })
      .order('name', { ascending: true });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    // Group by jabatan untuk memudahkan di frontend
    const groupedByJabatan = {};
    bawahanUsers?.forEach(user => {
      if (!groupedByJabatan[user.jabatan]) {
        groupedByJabatan[user.jabatan] = [];
      }
      groupedByJabatan[user.jabatan].push({
        id: user.id,
        name: user.name,
        email: user.email
      });
    });

    res.json({
      message: `Daftar bawahan dalam bidang ${currentUser.bidang}`,
      bidang: currentUser.bidang,
      data: bawahanUsers || [],
      grouped_by_jabatan: groupedByJabatan,
      total: bawahanUsers?.length || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get bawahan dalam bidang yang sama
app.get('/api/users/bawahan-bidang', authenticateToken, async (req, res) => {
  try {
    // Ambil bidang user current
    const { data: currentUser, error: userError } = await supabase
      .from('users')
      .select('bidang')
      .eq('id', req.user.id)
      .single();

    if (userError || !currentUser) {
      return res.status(400).json({ error: 'Data user tidak ditemukan' });
    }

    // Ambil semua user dalam bidang yang sama (kecuali diri sendiri)
    const { data: bawahanUsers, error } = await supabase
      .from('users')
      .select('id, name, jabatan, bidang')
      .eq('bidang', currentUser.bidang)
      .neq('id', req.user.id)
      .order('name', { ascending: true });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({
      message: `Daftar bawahan dalam bidang ${currentUser.bidang}`,
      bidang: currentUser.bidang,
      data: bawahanUsers || []
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint untuk accept disposisi oleh bawahan
app.post('/api/surat/:id/accept', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { atasan_jabatan } = req.body;

    // Update status disposisi (jika perlu)
    const { data: surat, error: suratError } = await supabase
      .from('surat_masuk')
      .update({
        status: 'processed',
        processed_by: req.user.id,
        accepted_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (suratError) {
      return res.status(400).json({ error: suratError.message });
    }

    // Kirim notifikasi ke atasan
    const { data: atasan } = await supabase
      .from('users')
      .select('id')
      .eq('jabatan', atasan_jabatan);

    if (atasan && atasan.length > 0) {
      const notifications = atasan.map(user => ({
        user_id: user.id,
        surat_id: id,
        message: `Disposisi telah diterima oleh ${req.user.jabatan}`,
        is_read: false,
        created_at: new Date().toISOString()
      }));

      await supabase
        .from('notifications')
        .insert(notifications);
    }

    res.json({
      message: 'Disposisi berhasil diterima',
      data: surat
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ✅ Daftarkan Handlebars helpers di awal
if (!Handlebars.helpers.eq) {
  Handlebars.registerHelper('eq', (a, b) => a === b);
}

if (!Handlebars.helpers.tanggalIndo) {
  Handlebars.registerHelper('tanggalIndo', function (value) {
    if (!value) return '-';
    const bulan = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    const date = new Date(value);
    if (isNaN(date)) return '-';
    return `${date.getDate()} ${bulan[date.getMonth()]} ${date.getFullYear()}`;
  });
}

// 🔥 NEW → helper untuk cek apakah array berisi nilai tertentu
if (!Handlebars.helpers.includes) {
  Handlebars.registerHelper('includes', function (array, value) {
    return Array.isArray(array) && array.includes(value);
  });
}

// 🔧 Fungsi bantu untuk olah tindakan
const prepareTemplateData = (surat) => {
  const tindakanArray = typeof surat.tindakan === 'string'
    ? surat.tindakan.split(',').map(item => item.trim())
    : surat.tindakan || [];

  const tindakanFlags = {
    tanggapan_dan_saran: tindakanArray.includes('Tanggapan dan Saran'),
    wakili_hadir_terima: tindakanArray.includes('Wakili / Hadir / Terima'),
    mendampingi_saya: tindakanArray.includes('Mendampingi Saya'),
    untuk_ditindaklanjuti: tindakanArray.includes('Untuk Ditindaklanjuti'),
    pelajari_telaah_sarannya: tindakanArray.includes("Pelajari / Telaa'h / Sarannya"),
    untuk_dikaji_sesuai_ketentuan: tindakanArray.includes('Untuk Dikaji Sesuai dengan Ketentuan'),
    untuk_dibantu_dipertimbangkan: tindakanArray.includes('Untuk Dibantu / Dipertimbangkan / Sesuai dengan Ketentuan'),
    selesaikan_proses_ketentuan: tindakanArray.includes('Selesaikan / Proses Sesuai Ketentuan'),
    monitor_realisasi_perkembangan: tindakanArray.includes('Monitor Realisasinya / Perkembangannya'),
    siapkan_pointers_sambutan: tindakanArray.includes('Siapkan Pointers / Sambutan / Bahan'),
    menghadap_informasi: tindakanArray.includes('Menghadap / Informasinya'),
    membaca_file_referensi: tindakanArray.includes('Membaca / File / Referensi'),
    agendakan_jadwalkan_koordinasi: tindakanArray.includes('Agendakan / Jadwalkan / Koordinasikan')
  };

  return {
    ...surat,
    tindakanArray,   // ← dibutuhkan oleh {{includes tindakanArray "..."}}
    tindakan: tindakanFlags
  };
};

// 📄 Endpoint untuk generate PDF
app.get('/api/surat/:id/pdf', authenticateToken, async (req, res) => {
  try {
    console.log('📥 Permintaan PDF untuk surat ID:', req.params.id);

    // Ambil data dari Supabase
    const { data: surat, error } = await supabase
      .from('surat_masuk')
      .select(`
        *,
        users!surat_masuk_created_by_fkey (name, jabatan),
        processed_user:users!surat_masuk_processed_by_fkey (name, jabatan)
      `)
      .eq('id', req.params.id)
      .single();

    if (error || !surat) {
      console.error('❌ Surat tidak ditemukan atau Supabase error:', error?.message || error);
      return res.status(404).json({ error: 'Surat not found', detail: error?.message });
    }

    // Siapkan path & template
    const templatePath = path.join(__dirname, 'templates', 'disposisi.html');
    const htmlTemplate = fs.readFileSync(templatePath, 'utf8');
    const template = Handlebars.compile(htmlTemplate);

    const preparedData = prepareTemplateData(surat);
    const tglDiterima = surat.created_at
      ? new Date(surat.created_at).toLocaleDateString('id-ID')
      : '-';

    const html = template({
      ...preparedData,
      tgl_diterima: tglDiterima,
      processed_by: surat.processed_user?.name || '-',
      jabatan: surat.processed_user?.jabatan || '-'
    });

    // Generate PDF pakai Puppeteer
    const browser = await puppeteer.launch({ headless: 'new' });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });

    const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true });
    await browser.close();

    console.log('✅ PDF berhasil dibuat. Mengirim ke client...');

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="disposisi-${surat.nomor_surat || surat.id}.pdf"`
    );
    res.send(pdfBuffer);
  } catch (err) {
    console.error('❌ Gagal generate PDF:', err);
    res.status(500).json({ error: 'Gagal membuat PDF. Cek log server.' });
  }
});

// Get dashboard data
app.get('/api/dashboard', authenticateToken, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('surat_masuk')
      .select(`
        *,
        users!surat_masuk_created_by_fkey (name, jabatan),
        processed_user:users!surat_masuk_processed_by_fkey (name, jabatan),
        surat_photos (id, foto_filename, foto_original_name, file_size)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }
    // Get user's surat masuk
    const { data: suratMasuk } = await supabase
      .from('surat_masuk')
      .select('*')
      .eq('created_by', req.user.id)
      .order('created_at', { ascending: false });

    // Get surat for user's jabatan
    const { data: suratUntukJabatan } = await supabase
      .from('surat_masuk')
      .select('*')
      .eq('tujuan_jabatan', req.user.jabatan)
      .order('created_at', { ascending: false });

    const dataWithPhotoInfo = data?.map(surat => ({
      ...surat,
      photo_count: surat.surat_photos ? surat.surat_photos.length : 0,
      has_photos: surat.surat_photos && surat.surat_photos.length > 0,
      photos: surat.surat_photos?.map(photo => ({
        id: photo.id,
        filename: photo.foto_original_name,
        size: photo.file_size,
        url: `/api/surat-masuk/photo/${photo.id}`
      })) || []
    })) || [];
    // Get unread notifications count
    const { count: unreadNotifications } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', req.user.id)
      .eq('is_read', false);

    res.json({
      suratMasuk: suratMasuk || [],
      suratUntukJabatan: suratUntukJabatan || [],
      unreadNotifications: unreadNotifications || 0,
      data: dataWithPhotoInfo,
      total: dataWithPhotoInfo.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

//-----------------------staff---------------//
app.get('/api/notifications/staff', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, unread_only = false } = req.query;
    const offset = (page - 1) * limit;

    let query = supabase
      .from('notifications')
      .select(`
        *,
        surat_masuk:surat_id (
          id,
          nomor_surat,
          asal_instansi,
          tujuan_jabatan,
          perihal,
          keterangan,
          disposisi_kepada,
          tindakan,
          sifat,
          catatan,
          status,
          created_at,
          processed_at
        )
      `)
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (unread_only === 'true') {
      query = query.eq('is_read', false);
    }

    const { data: notifications, error } = await query;

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    // Hitung total unread notifications
    const { count: unreadCount } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', req.user.id)
      .eq('is_read', false);

    res.json({
      notifications,
      unread_count: unreadCount,
      current_page: parseInt(page),
      per_page: parseInt(limit)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/surat/:id/forwarded-details', authenticateToken, async (req, res) => {
  try {
    // Ambil data surat dengan foto
    const { data: surat, error: suratError } = await supabase
      .from('surat_masuk')
      .select(`
        *,
        surat_photos (
          id,
          foto_path,
          foto_filename,
          foto_original_name,
          file_size
        ),
        users:created_by (
          name,
          jabatan
        )
      `)
      .eq('id', req.params.id)
      .single();

    if (suratError || !surat) {
      return res.status(404).json({ error: 'Surat tidak ditemukan' });
    }

    // Cek apakah user berhak akses surat ini (ada notifikasi untuk surat ini ATAU sesuai jabatan)
    const { data: notification, error: notifError } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', req.user.id)
      .eq('surat_id', req.params.id)
      .maybeSingle(); // maybeSingle karena bisa jadi null

    // Cek juga apakah surat ditujukan untuk jabatan user
    const hasAccess = notification || surat.tujuan_jabatan === req.user.jabatan;

    if (!hasAccess) {
      return res.status(403).json({ error: 'Anda tidak memiliki akses ke surat ini' });
    }

    // Ambil riwayat forward/disposisi surat ini
    const { data: forwardHistory } = await supabase
      .from('notifications')
      .select(`
        *,
        users:user_id (name, jabatan)
      `)
      .eq('surat_id', req.params.id)
      .order('created_at', { ascending: true });

    res.json({
      surat,
      notification,
      forward_history: forwardHistory || [],
      has_photos: surat.surat_photos && surat.surat_photos.length > 0,
      photo_count: surat.surat_photos ? surat.surat_photos.length : 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 3. ENDPOINT UNTUK DASHBOARD SURAT MASUK BAWAHAN (DISESUAIKAN)
app.get('/api/dashboard/forwarded-surat', authenticateToken, async (req, res) => {
  try {
    // Ambil semua surat yang diforward ke user ini
    const { data: notifications } = await supabase
      .from('notifications')
      .select(`
        surat_id,
        created_at,
        is_read,
        message,
        surat_masuk:surat_id (
          id,
          nomor_surat,
          asal_instansi,
          tujuan_jabatan,
          perihal,
          keterangan,
          status,
          disposisi_kepada,
          created_at
        )
      `)
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });

    // Ambil juga surat yang langsung ditujukan ke jabatan user (bukan dari forward)
    const { data: directSurat } = await supabase
      .from('surat_masuk')
      .select(`
        id,
        nomor_surat,
        asal_instansi,
        tujuan_jabatan,
        perihal,
        keterangan,
        status,
        disposisi_kepada,
        created_at
      `)
      .eq('tujuan_jabatan', req.user.jabatan)
      .order('created_at', { ascending: false });

    // Gabungkan dan remove duplicate
    const allSurat = [];

    // Dari notifications (forwarded)
    if (notifications) {
      notifications.forEach(notif => {
        if (notif.surat_masuk) {
          allSurat.push({
            ...notif.surat_masuk,
            is_forwarded: true,
            notification_id: notif.surat_id,
            forward_message: notif.message,
            notification_read: notif.is_read,
            notification_date: notif.created_at
          });
        }
      });
    }

    // Dari direct surat (yang belum ada di notifications)
    if (directSurat) {
      directSurat.forEach(surat => {
        const existingIndex = allSurat.findIndex(s => s.id === surat.id);
        if (existingIndex === -1) {
          allSurat.push({
            ...surat,
            is_forwarded: false,
            notification_read: true // direct surat dianggap sudah "dibaca"
          });
        }
      });
    }

    // Group by status untuk statistik
    const stats = {
      total: allSurat.length,
      unread: allSurat.filter(s => !s.notification_read).length,
      today: allSurat.filter(s => {
        const today = new Date().toDateString();
        const suratDate = new Date(s.notification_date || s.created_at).toDateString();
        return today === suratDate;
      }).length,
      pending: allSurat.filter(s => s.status === 'pending').length,
      processed: allSurat.filter(s => s.status === 'processed').length
    };

    res.json({
      statistics: stats,
      recent_forwarded: allSurat.slice(0, 10),
      all_surat: allSurat
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 4. ENDPOINT UNTUK MARK NOTIFICATION SEBAGAI DIBACA (SUDAH BENAR)
app.put('/api/notifications/staff/:id/read', authenticateToken, async (req, res) => {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', req.params.id)
      .eq('user_id', req.user.id);

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    res.json({ message: 'Notifikasi berhasil ditandai sebagai dibaca' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 5. ENDPOINT UNTUK MARK SEMUA NOTIFICATION SEBAGAI DIBACA (SUDAH BENAR)
app.put('/api/notifications/staff/mark-all-read', authenticateToken, async (req, res) => {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', req.user.id)
      .eq('is_read', false);

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    res.json({ message: 'Semua notifikasi berhasil ditandai sebagai dibaca' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// 7. ENDPOINT UNTUK AMBIL FOTO SURAT
app.get('/api/surat/staff/:id/photos', authenticateToken, async (req, res) => {
  try {
    // Cek akses dulu
    const { data: surat } = await supabase
      .from('surat_masuk')
      .select('tujuan_jabatan')
      .eq('id', req.params.id)
      .single();

    if (!surat) {
      return res.status(404).json({ error: 'Surat tidak ditemukan' });
    }

    const { data: notification } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', req.user.id)
      .eq('surat_id', req.params.id)
      .maybeSingle();

    const hasAccess = notification || surat.tujuan_jabatan === req.user.jabatan;

    if (!hasAccess) {
      return res.status(403).json({ error: 'Anda tidak memiliki akses ke surat ini' });
    }

    // Ambil foto
    const { data: photos, error } = await supabase
      .from('surat_photos')
      .select('*')
      .eq('surat_id', req.params.id)
      .order('created_at', { ascending: true });

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    res.json({ photos: photos || [] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});